# gaussian-dsh-plugin 项目状态记录

> 最后更新：2026-10-20（M0-M6 全部落地，onedir 打包 exe 已 smoke 通过）

## 硬件环境
- CPU: AMD Ryzen 7 9700X（8核16线程）
- 内存: 15.1 GB（Gaussian 预算 12GB，后端 soft 1024MB / hard 1800MB）
- OS: Windows
- Gaussian 16: D:\G16W\g16.exe；formchk: D:\G16W\formchk.exe
- Multiwfn 3.8: D:\Multiwfn\Multiwfn_3.8_bin_Win64\Multiwfn.exe
- VMD 1.9.3: D:\VMD\vmd.exe
- Python(base, D盘): D:\YDW\Trae_Gromacs\miniconda3\python.exe（3.13.13）

## 当前版本
- 插件/后端版本: 0.2.0
- 后端: FastAPI + uvicorn workers=1，端口 8765
- 前端: esbuild → lib/（src/ 改动后需 `node scripts/build.mjs` 重新打包）
- 打包产物: runtimes/win32-x64/gaussian-backend/（onedir，exe + _internal）+ runtime.json(sha256)

## 里程碑状态

### M0 基础修复（完成，已验证）
- [x] %NoSave/%Chk 顺序：%nosave 在 %chk 之前，chk 保留
- [x] mem/nproc 走 settings.default_mem/default_nproc，不再硬编码
- [x] ChemComputeScheduler（resource_scheduler.py）四者互斥，8 项测试通过
- [x] /v1/health（ok/service/version/pid/instance_id/uptime/compute_lease/memory）
- [x] /v1/admin/shutdown（managed token 校验，保留运行中 Gaussian 子进程）
- [x] Sobko frozen fix：get_sobko_python_exe()，冻结用 SOBKO_PYTHON_EXE
- [x] process_utils.py：spawn_subprocess / kill_process_tree / pid_alive(Windows tasklist)
- [x] entrypoint.py；uvicorn workers=1；startup reconcile + ready record

### M1 RDKit SMILES → Gaussian（完成，6 组测试通过）
- [x] backend/smiles/：MolFromSmiles→canonical→电荷→多片段拒绝→手性告警→AddHs
- [x] 保守推断 multiplicity（闭壳层 singlet / 单自由基 doublet；模糊组态抛 AmbiguousSpinError）
- [x] ETKDGv3(numThreads=1) → MMFF94s 取收敛最低能构象；MMFF 缺参数不 fallback UFF
- [x] REST: /v1/molecules/from-smiles、/v1/gaussian-inputs/from-smiles

### M2 Multiwfn 后处理框架（核心完成）
- [x] backend/postprocess/：models/gaussian_tools/multiwfn/manager/vmd；profiles/multiwfn-3.8.json 版本化菜单
- [x] fchk_reader.py：直接解析 fchk，HOMO/LUMO/gap(eV) + MO 能级 SVG（CH3Cl.fchk 验证）
- [x] /v1/postprocess/capabilities、POST/GET /v1/postprocess/tasks
- [ ] 真实 Multiwfn spawn 跑 cube 导出未端到端（菜单数字待真实 smoke 后回填 profile）

### M3 VMD headless（框架完成）
- [x] templates/orbital.tcl、esp_surface.tcl、rdg.tcl（-dispdev text + TachyonInternal）
- [x] vmd.py 三个渲染函数，TGA→PNG(Pillow)；VMD headless 启动 exit 0 已验证
- [ ] 真实 cube 渲染 PNG 端到端未跑（examples 无现成 .cub）

### M4 PyInstaller onedir 打包（完成，exe smoke 通过）
- [x] packaging/gaussian-backend.spec（onedir，排除 Qt，收集 conda SSL DLL）
- [x] scripts/build_backend.ps1（pathlib dist-info 临时改名→finally 还原，可逆零下载）
- [x] scripts/deploy_runtime.ps1（复制到 runtimes + 生成 runtime.json sha256 清单）
- [x] 实跑：exe 16.8MB，启动打 ready record，health 200，冻结环境 RDKit SMILES 可用，shutdown 受控退出
- [x] 修复 postprocess manager 的 pydantic model_dump（原误用 dataclasses.asdict）

### M5 Cordis managed lifecycle（完成，代码落地）
- [x] src/index.js BackendManager：probe health→reuse(owned=false)；managed spawn→轮询 health
- [x] ctx.inject(["subprocess"]) 启动；disposer 只 terminate owned，reuse 不动，Gaussian 子进程始终保留
- [x] external 模式直连 baseUrl；找不到 exe/subprocess 优雅降级不崩
- [x] 后端 ready record stdout JSON；health 校验 service 名防误认
- 注：前端未在真实 DSH 环境联调（无 node_modules，未跑 esbuild）

### M6 加固（完成，已验证）
- [x] M6a memory_guard.py：psutil 后台采样 RSS，soft 告警/hard 拒绝新重计算，不杀进程
- [x] M6b artifact_gc.py：cube 7天/图片30天/日志30天 TTL，绝不删 chk/fchk/gjf/json；startup + /v1/admin/gc
- [x] M6c 原子数上限(GAUSSIAN_MAX_ATOMS=300) + 网格点数上限预检，超限 422
- [x] M6d Windows pid_alive(tasklist) 统一；Multiwfn profile 主版本 fail-fast；超时走 kill_process_tree

## 数据目录
- 任务库: C:\Users\Administrator\.gaussian-dsh\jobs\；日志: ...\logs\；后处理: ...\postprocess\
- Gaussian 工作目录: E:\YDW\ChemDatas\Gjf\（GC 不扫此目录，避免误删用户文件）

## 时间线
| 日期 | 事件 |
|------|------|
| 2026-10-20 | 项目逆推；M0 完成（%NoSave 顺序、scheduler、health、Sobko frozen） |
| 2026-10-20 | M1 完成（RDKit SMILES→3D→Gaussian） |
| 2026-10-20 | M2 完成（Multiwfn profile、fchk_reader、MO 图） |
| 2026-10-20 | M3 完成（VMD headless 封装） |
| 2026-10-20 | M5 完成（managed spawn/reuse/dispose、reconcile、ready record） |
| 2026-10-20 | M6 完成（memory guard、artifact GC、大体系预检、pid_alive/版本 fail-fast） |
| 2026-10-20 | M4 完成（onedir 打包，绕过 pathlib backport、排除 Qt、收 SSL DLL，exe smoke 通过） |

## 已验证
- [x] 后端 24 个 py 文件全部 py_compile 通过；TestClient 综合回归通过
- [x] 打包 exe：ready record、health(含 memory)、冻结 RDKit 乙醇/苯、postprocess 任务创建、shutdown token 403/受控退出
- [x] formchk/Multiwfn/VMD 三个外部程序 capabilities 全部探测到
- [x] 301 原子 422 拒绝；GC dry_run 不删保护文件；base 环境 pathlib metadata 构建后完好还原

## 待办（非阻塞）
- [ ] 前端：装 node_modules 后 `node scripts/build.mjs` 产出 lib/，在真实 DSH 联调 managed spawn
- [ ] 端到端：真实 chk→formchk→Multiwfn 实跑 cube→VMD 出 PNG，据真实菜单回填 profile
- [ ] one-file 版本（onedir 验证稳定后再切）
