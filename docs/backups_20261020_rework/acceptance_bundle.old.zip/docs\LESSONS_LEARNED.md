# 经验文档（Lessons Learned）

> 记录执行过程中的错误和修复经验，避免重复踩坑。

## 2026-10-20

### 1. Gaussian Link 0 命令顺序：%NoSave 必须在 %Chk 之前
- **错误**：先写 `%chk=xxx.chk` 再写 `%nosave`，Gaussian 会删除 chk 文件
- **原因**：%NoSave 会删除其之前命名的所有 scratch 文件（包括 chk）
- **正确写法**：`%mem=... %nprocshared=... %nosave %chk=xxx.chk`，或者直接不写 %nosave
- **影响**：后处理链（formchk → Multiwfn）拿不到 checkpoint，整个流程断裂
- **来源**：https://www.cenapad.unicamp.br/parque/manuais/Gaussian/00000483.htm

### 2. PyInstaller one-file 模式下 sys.executable 指向 exe 自己
- **错误**：子进程调用 `[sys.executable, script.py]`，冻结后变成 `gaussian-backend.exe script.py`
- **原因**：PyInstaller 冻结后 sys.executable 是打包后的 exe 路径，不再是 python.exe
- **解决方案**：新增 SOBKO_PYTHON_EXE 环境变量配置，冻结模式下必须显式指定 Python 路径
- **来源**：https://www.pyinstaller.org/en/stable/runtime-information.html

### 3. 15 GB 内存机器上的资源互斥
- **教训**：Gaussian 12 GB + Multiwfn 网格计算 + VMD 渲染，三者绝对不能同时跑
- **解决方案**：ChemComputeScheduler lease 机制，重型计算统一互斥
- **网格估算**：250³ 单 float64 数组 = 119 MiB，6 个数组 = 715 MiB；300³ 就到 2 GB
- **默认限制**：POSTPROCESS_MAX_GRID_POINTS = 16,000,000（≈252³）

### 4. Multiwfn 菜单数字会随版本漂移
- **教训**：不能把菜单数字硬编码在 Python 代码里
- **解决方案**：版本化 profile JSON + banner probe，未知版本 fail-fast
- **profile 文件**：backend/postprocess/profiles/multiwfn-3.8.json

### 5. RDKit MMFF 默认忽略片段间相互作用
- **教训**：盐（如 [NH4+].[Cl-]）用 MMFF 优化时，阴阳离子相对位置没有物理意义
- **原因**：MMFF API 默认 ignoreInterfragInteractions=true
- **解决方案**：多片段体系默认拒绝，要求 allow_disconnected=True 才处理
- **来源**：https://www.rdkit.org/docs/cppapi/MMFF_8h_source.html

### 6. PyInstaller 启动即退出：旧 pathlib backport 的 dist-info（M4）
- **现象**：base 环境装了 `pathlib 1.0.1` backport（只剩 dist-info 元数据，无包代码，import 仍走标准库），PyInstaller 6.x 在 compat.py 启动期 `distribution("pathlib")` 命中元数据就 raise SystemExit，命令行参数无法绕过。
- **错误做法**：在 base 里 pip uninstall（违反"不污染现有工作流环境"规则）。
- **正确做法（零下载、可逆）**：构建脚本 try 里把 `pathlib-1.0.1.dist-info` 临时改名为 `.__tmp_rename`，finally 无条件改回；不卸载、不删文件，环境最终与构建前一致。备份在 docs/backups_20261020/。
- **检查点**：改名后 `python -m PyInstaller --version` 能正常返回即说明绕过生效。

### 7. PyInstaller 拒绝同时收集 PyQt5 + PyQt6（M4）
- **现象**：base 环境两套 Qt 绑定并存，分析阶段报"multiple Qt bindings packages"中止。
- **解决**：后端根本不用 Qt，在 spec 的 excludes 里显式排除 PyQt5/PyQt6/PySide2/PySide6/qtpy。

### 8. conda 的 OpenSSL DLL 不会被 PyInstaller 自动收集（M4）
- **现象**：exe 启动报 `ImportError: DLL load failed while importing _ssl: 找不到指定的程序`（anyio→ssl→_ssl.pyd 缺 libcrypto/libssl）。
- **原因**：标准 hook 只收证书，conda 的 libssl-3-x64.dll/libcrypto-3-x64.dll 在 `Library\bin`，不在 pythonDLLs。
- **解决**：spec 里按 `sys.executable` 推导 `Library\bin`，glob `libssl-*.dll/libcrypto-*.dll` 加入 binaries（跳过 .conda_trash/.pdb）。

### 9. PowerShell 的 try 必须配 catch 或 finally，且 try 内不要用 exit（M4）
- **现象**：解析报"Try 语句缺少 Catch 或 Finally"，常因 try 块内 `exit 1` 让控制流与大括号错位。
- **解决**：try/catch/finally 完整结构，块内用 `throw` + `$buildOk` 标志，退出码在 finally 之后统一判断。

### 10. pydantic 模型不能用 dataclasses.asdict（M2 遗留，M6 回归时暴露）
- **现象**：postprocess manager 把 pydantic 的 PostprocessTask 传给 `dataclasses.asdict()`，create_task 保存时抛 `TypeError: asdict() should be called on dataclass instances`。
- **原因**：M2 写 manager 时误用了 dataclasses 工具，而任务模型是 pydantic BaseModel；此前端到端没真正创建过 postprocess 任务，所以一直没触发。
- **解决**：全部改用 `task.model_dump()`；pydantic 写入 JSON 用 model_dump，不要 import asdict。
- **提醒**：单测只覆盖命令生成、没走到持久化时，这类 bug 会潜伏，端点级 TestClient 回归才能抓到。

### 11. DSH managed 生命周期协议（M5）
- 前端 `ctx.inject(["subprocess"], child => child.effect(() => { owned.start(); return async () => owned.dispose(); }))`；
- 后端 stdout 打一行 ready record `{"event":"ready","service","version","baseUrl"}`，前端也可用轮询 /v1/health 兜底；
- dispose 只 terminate 自己 owned 的进程，reuse 的别人进程绝不动；Gaussian 子进程由 /v1/admin/shutdown 保留、下次启动 reconcile 接管。
- health 必须校验 `service` 名，不能只看 200，避免把同端口的其他服务误当后端。
