# 返工修复对照报告（第二轮静态验收前）

> 日期：2026-10-20　基线：`acceptance_bundle.zip` 首轮评审结论"需返工"（9 Blocker / 12 Major / 3 Minor）
> 说明：本报告逐条对照首轮问题清单，给出修复位置、做法与本地验证。未实跑真实 Gaussian/Multiwfn/VMD 的项已如实标注为"代码层修复，待端到端 smoke"。

## 一、Blocker（B1–B9）

| 编号 | 问题 | 修复位置 | 做法 | 验证 |
|------|------|----------|------|------|
| **B1** | Gaussian 未取统一 lease，RDKit 入口也未取，并发可同时通过 has_running | `backend/job_manager.py` `submit()`；`backend/app.py` 两个 SMILES 端点；`resource_scheduler.py` | submit 先生成 job_id，再 `chem_scheduler.acquire(job_id,"gaussian")`（scheduler 内部加锁，消除并发同时通过检查）；启动失败/异常路径 `_release_lease`；reconcile 接管存活 PID 时重新 acquire。两个 SMILES 端点对 `smiles_to_3d` 短持 `rdkit` lease（try/finally），ResourceBusyError→409。Gaussian Popen 加 `CREATE_NO_WINDOW \| CREATE_NEW_PROCESS_GROUP(0x200)` 脱离后端控制台组 | 代码走查；scheduler 8 项测试保留；TestClient 回归通过 |
| **B5** | 启动恢复/GC 用未定义的 `app.logger`，异常处理内二次调用会 AttributeError | `backend/app.py` | 引入标准库 `logging.getLogger("gaussian-dsh-backend")`，替换全部 `app.logger.*`；覆盖 adopted job、GC 删除、reconcile 异常三条启动路径 | py_compile；TestClient startup 不报错 |
| **B6** | 管理端点无 token 时匿名可 shutdown/GC，CORS `*`+credentials | `backend/app.py` `_require_admin()`；CORS 中间件 | 统一鉴权：配 token 校验 Bearer；未配 token 仅放行回环 host（127.0.0.1/::1/localhost）。CORS 由 `*`+credentials 收紧为回环白名单、credentials=False、只开放 GET/POST 与必要头 | TestClient：非回环匿名 POST `/v1/admin/gc` → 403 |
| **B7** | `/v1/jobs` 绕过原子数与资源上限，原始 GJF 原样提交 | `backend/gaussian_input.py` 新增 `validate_gjf()`/`_parse_mem_to_mb()`；`job_manager.submit()` 调用 | 提交边界解析原始 GJF：原子数≤max_atoms、`%mem` 换算 MB 不超预算、`%nprocshared`≤上限、电荷/多重度合法（多重度=2S+1，≥1，不要求奇数，双重态=2 合法） | 单测：301 原子拒绝、20GB 拒绝、合法乙醇通过；TestClient ok=false |
| **B8** | MP2 误把 SCF 参考态当相关能；EUMP2 不支持 Fortran 科学计数 | `backend/gaussian_output.py` 能量段 | 按方法选择最终能量：MP2 取 EUMP2，CCSD 取 E(CCSD)，HF/DFT 回退最后 SCF Done；数值正则兼容 `E[+-]dd` 科学计数 | 单测：MP2 final=-76.234567（非 -76.01） |
| **B9** | stop_job 凭 PID、不查返回码，PID 复用误杀/误报 stopped | `backend/job_manager.py` `stop_job()`/`_finalize_if_dead()` | taskkill 后检查返回码，轮询最多 5 秒确认 PID 消失，未确认不落 stopped、不允许提交新任务；统一结束判据 | 代码走查；与 M1 共用终态逻辑 |
| **B2** | managed dispose 可能 terminate 仍在跑的 Gaussian | `src/index.js` `dispose()`；后端独立进程组 | dispose 先受控 POST `/v1/admin/shutdown`，等 waitForExit；仅超时未退才兜底 terminate。配合后端 CREATE_NEW_PROCESS_GROUP，Gaussian 不在后端可清理句柄范围 | 代码走查（真实 DSH 联调待办） |
| **B3** | `if(handle.done)` 把 Promise 当布尔退出状态 | `src/index.js` `_waitReady()` | `handle.done.then(resolve)` 订阅退出，与 health 轮询 `Promise.race`，进程提前退出立即报错而非空等到超时 | esbuild bundle 通过 |
| **B4** | spawn `cwd: dataDir \|\| undefined`，而 SpawnSpec.cwd 是必需字符串 | `src/index.js` `_resolveCwd()` | 解析真实存在的绝对目录（dataDir→exe 所在目录，不存在则 mkdir），拿不到时**省略 cwd 键**而非传 undefined | esbuild bundle 通过 |

## 二、Major（M1–M12）

| 编号 | 问题 | 修复位置 | 做法 | 验证 |
|------|------|----------|------|------|
| **M1** | has_running 见原 PID 退出就无条件标 failed，忽略 Normal termination | `backend/job_manager.py` `_finalize_if_dead()` | 统一终态 reconciliation：读日志 "Normal termination of Gaussian" 落 completed，否则 failed；has_running/get_job/reconcile 复用同一判据 | 代码走查 |
| **M2** | orbitals/esp/rdg 只生成命令却标 completed、返回 ok=true | `backend/postprocess/manager.py` | 三分支标 `prepared`（awaiting_execution），仅命令落盘；mo_levels 校验 SVG 存在非零才 completed；final_status 变量统一落状态 | 代码走查 |
| **M3** | DSH 前端未注册后处理工具 | `src/index.js` 新增 4 个工具 | `postprocess_capabilities`、`create_postprocess_task`、`get_postprocess_task`、`list_postprocess_tasks`，把状态与产物路径映射回工具结果 | esbuild bundle 含新工具名（13 处匹配） |
| **M4** | Multiwfn probe_version 硬返回 "3.8" | `backend/postprocess/multiwfn.py` `probe_version()` | 真启动 exe、input="q\n"、抓 banner 正则 `Multiwfn (V?\d+\.\d+...)`；超时/抓不到返回 None 不伪造 | 代码走查（实机版本探测待 smoke） |
| **M5** | 网格预检用固定三档，未按真实包围盒 | `backend/postprocess/manager.py` | 三档标注为保守上界；新增 `_cube_header_point_count()` 预留生成后读 nx·ny·nz 复核钩子；当前枚举档位最大值 410 万 < 1600 万上限，不会越限 | 代码走查；真实网格复核待执行器接入 |
| **M6** | GC 只扫 data_dir，产物散在 work_dir 不被回收 | `backend/postprocess/manager.py` | 产物目录改 `data_dir/postprocess/<task_id>`，纳入 GC 扫描 | 代码走查 |
| **M7** | `_recv_json` 阻塞 readline 无法超时，stderr=PIPE 未消费 | `backend/sobko_client.py` | 后台 stdout 泵线程写共享字节缓冲，`_recv_json` 轮询缓冲按 Content-Length 取帧，真超时返回；stderr 独立线程消费留最近 20 行；超时退出附 stderr | 单测：卡死子进程 1.51s 返回 None（非永久阻塞）；直接塞缓冲帧解析正确 |
| **M8** | VMD returncode=0 但 TGA 缺失仍返回 PNG 路径 | `backend/postprocess/vmd.py` `_require_tga()` | 三渲染函数强制校验 TGA 存在、非零、可解码（Pillow verify），缺失即 raise；Pillow 缺失显式返回 TGA | 代码走查（实渲染待 smoke） |
| **M9** | 开壳层 MO 图只画 alpha，用 alpha 定义 gap | `backend/fchk_reader.py` `generate_mo_level_svg()` | 闭壳层单栏；开壳层 alpha/beta 两栏并列，各自 HOMO/LUMO 与 gap；缺 beta 通道显式告警 | 单测：开壳层双栏、闭壳层单栏 |
| **M10** | HOMO/LUMO 遍历优化各步取全局最大，非终态 | `backend/gaussian_output.py` | 取【最后一组】occ/virt（终态 SCF），合理性校验后采用 | 单测：最后一对 -0.25/-0.05 |
| **M11** | managed start 以 void 启动，dispose 与启动竞态 | `src/index.js` | 加 `this.disposed` 终态标志；_launch/probe/waitReady 各处检查；卸载后不再把进程置 owned | esbuild bundle 通过 |
| **M12** | stdout/stderr pipe 无消费者，缓冲满反堵 | `src/index.js` spawn stdio | 改用 health 轮询判定就绪，stdio 设 ignore，避免管道堆积 | esbuild bundle 通过 |

## 三、Minor（m1–m3）

| 编号 | 问题 | 修复位置 | 做法 |
|------|------|----------|------|
| **m1** | package.json 0.1.0 与后端 0.2.0 不一致 | `package.json` | version → 0.2.0 |
| **m2** | client.js 硬编码 127.0.0.1:8765 | `src/client.js` | 提 `backendBase()`，优先 `window.GAUSSIAN_BACKEND_URL`，回环兜底，三处替换 |
| **m3** | one-file 开关误导、找不到 exe 仍成功退出 | `scripts/build_backend.ps1` | 未实现 one-file 时直接 throw 拒绝；onedir exe 缺失改为 exit 1 |

## 四、本地验证汇总

- 后端 24 个 `.py` 全部 `py_compile` 通过（FAIL=0）。
- 前端 `src/index.js`、`src/client.js` esbuild bundle 成功；`lib/` 已用现成 esbuild 重打。
- TestClient 综合回归：health(0.2.0) 200、status 200、capabilities 嵌套结构正常、301 原子与 20GB mem 被 ok=false 拒绝、匿名 admin/gc 403。
- 针对性单测：MP2 能量、最后一对轨道、开壳层 MO 双栏、Sobko 真超时、validate_gjf 三场景，均通过。

## 五、仍需端到端 smoke（非代码缺陷，静态验收不判 blocker）

1. 后端源码改动后需用 `scripts/build_backend.ps1` 重新 PyInstaller onedir 打包 + `deploy_runtime.ps1` 重部署（当前 runtimes exe 仍是返工前版本）。
2. 真实 chk→formchk→Multiwfn 实跑 cube→VMD 出 PNG，据真实菜单回填 profile。
3. 真实 DSH 环境联调 managed spawn/dispose 与新注册的后处理工具。
