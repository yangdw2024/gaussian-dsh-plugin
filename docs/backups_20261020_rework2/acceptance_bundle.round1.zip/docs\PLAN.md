# gaussian-dsh-plugin 扩展规划文档

> 创建时间：2026-10-20
> 状态：M0-M6 全部完成（2026-10-20）；仅剩真实端到端 Multiwfn/VMD 联调与 DSH 内前端联调
> 作者：YDW + Doubao

## 一、项目逆推结论

### 现有架构
- **前端**：Cordis 插件（src/index.js），13 个工具，HTTP 调用后端
- **后端**：Python FastAPI（backend/app.py），17 个 REST 端点
- **任务管理**：JobManager 串行提交（running 即拒绝新任务）
- **知识库**：Sobko MCP stdio 子进程（BM25-only）
- **基组库**：BSE REST API 客户端
- **打包**：esbuild 前端 → lib/；后端未打包，直接 python -m backend.app

### M0 级问题（必须先修）
1. **%NoSave/%Chk 顺序错误**：gaussian_input.py 先写 %chk 再写 %nosave，Gaussian 会删除 chk 文件，导致 formchk/Multiwfn 后处理链断裂
2. **backendMode: managed 是空壳**：apply() 只注册工具，不 spawn/health-check/dispose backend
3. **Sobko sys.executable 问题**：PyInstaller 冻结后 sys.executable 指向 exe 自己，不再是 python.exe
4. **mem/nproc 硬编码**：gaussian_input.py 硬编码 "12GB"/8，与 settings.default_mem/default_nproc 两套配置漂移

## 二、目标架构

```
DSH 客户端（Cordis 插件）
  │
  ├── HTTP 工具注册（Cordis）
  │
  ▼
FastAPI 后端（gaussian-backend.exe）
  │
  ├── ChemComputeScheduler（统一计算资源互斥）
  │     ├── Gaussian 16（独占 lease）
  │     ├── Multiwfn（独占 lease）
  │     ├── VMD render（独占 lease）
  │     ├── RDKit 重计算（独占 lease）
  │     └── 轻量任务（无 lease：log 解析、BSE 查询、Sobko、status）
  │
  ├── 现有模块（已稳定）
  │     ├── gaussian_input.py / gaussian_output.py
  │     ├── job_manager.py / basis_set.py
  │     ├── sobko_client.py / keywords.py
  │
  ├── 新增模块
  │     ├── resource_scheduler.py（M0）
  │     ├── process_utils.py（M0）
  │     ├── entrypoint.py（M4）
  │     ├── fchk_reader.py（M2）
  │     ├── smiles/rdkit_builder.py（M1）
  │     └── postprocess/（M2-M3）
  │           ├── manager.py / gaussian_tools.py
  │           ├── multiwfn.py / vmd.py
  │           ├── profiles/multiwfn-3.8.json
  │           └── templates/*.tcl
  │
  └── 外部程序（配置检测，不捆绑）
        ├── Gaussian 16 (D:\G16W)
        ├── Multiwfn 3.8
        ├── VMD
        └── formchk.exe
```

## 三、里程碑

| 里程碑 | 内容 | 验收标准 | 状态 |
|--------|------|----------|------|
| **M0** | 基础修复：%NoSave/%Chk、统一 settings、scheduler、health、process_utils、Sobko frozen fix | checkpoint 能保留；两个 compute job 永远不能同时拿 lease；/v1/health 返回正常 | ✅ 已完成（单元+TestClient 验证） |
| **M1** | RDKit SMILES → Gaussian 输入 | ethanol/ion/radical/stereo/salt/diradical 测试全部符合预期 | ✅ 已完成（6 组测试，冻结 exe 内复跑通过） |
| **M2** | Multiwfn 后处理：formchk、version profile、HOMO/LUMO、ESP、RDG | 小分子 .chk → fchk → cube 全自动 | 🟡 框架完成；真实 Multiwfn spawn 待端到端 |
| **M3** | VMD headless render：orbital/ESP/RDG Tcl、TGA→PNG | 无 GUI 生成稳定图片 | 🟡 框架完成；真实 cube 渲染待端到端 |
| **M4** | PyInstaller：RDKit DLL、templates/profile datas、Sobko frozen fix | 干净 Win11 环境启动 exe 后 /v1/health 正常 | ✅ 已完成（onedir exe smoke：health/RDKit/shutdown 通过） |
| **M5** | Cordis managed lifecycle：spawn/reuse/ownership/shutdown | 启插件自动启动；卸插件关闭 backend；运行中 Gaussian 不受热重载影响 | ✅ 代码完成（真实 DSH 内联调待做） |
| **M6** | 加固：memory guard、artifact GC、timeouts、version checks | 大体系被提前拒绝而非 Windows OOM | ✅ 已完成（hard 拒绝/GC/300 原子 422/版本 fail-fast） |

## 四、关键设计决策

1. **重型计算统一互斥**：Gaussian、Multiwfn、VMD、RDKit 重计算四者互斥，用 ChemComputeScheduler 的 lease 机制保证
2. **Multiwfn 菜单版本化**：不硬编码菜单数字，用 multiwfn-3.8.json profile + banner probe，未知版本 fail-fast
3. **managed shutdown 不杀正在跑的 Gaussian**：DSH 热重载 → Cordis disposer → backend shutdown 时，保留 Gaussian 子进程，下次启动 reconcile
4. **Uvicorn 单 worker**：workers=1，保证 scheduler 单实例
5. **大文件不走 tool JSON**：cube/PNG/长日志用 artifact path + 下载接口，不塞进 tool response（现有 1 MiB guard）
6. **SMILES 化学边界严格**：盐/多片段/过渡金属/多自由基/未指定手性，不包装成"一键可靠结构"

## 五、15 GB 内存约束

| 进程 | 内存上限 |
|------|----------|
| FastAPI idle | < 250 MB |
| FastAPI + RDKit | < 600 MB typical |
| Backend soft warning | ≈ 1.0 GB |
| Backend hard reject | ≈ 1.8 GB |
| Gaussian running | 12 GB（禁止 Multiwfn/VMD 同时跑） |

- POSTPROCESS_MAX_GRID_POINTS = 16_000_000（≈252³）
- Multiwfn threads = 2（不是 16/24）
- RDKit threads = 1
- VMD = 1 process
- Uvicorn = 1 worker

## 六、文件结构（目标）

```
gaussian-dsh-plugin/
├── backend/
│   ├── __init__.py
│   ├── app.py
│   ├── entrypoint.py          # [新增 M4]
│   ├── config.py
│   ├── resource_scheduler.py  # [新增 M0]
│   ├── process_utils.py       # [新增 M0]
│   ├── memory_guard.py        # [新增 M6a] RSS soft/hard 守卫
│   ├── artifact_gc.py        # [新增 M6b] TTL 回收
│   ├── gaussian_input.py
│   ├── gaussian_output.py
│   ├── job_manager.py
│   ├── fchk_reader.py          # [新增 M2]
│   ├── basis_set.py
│   ├── sobko_client.py
│   ├── keywords.py
│   ├── smiles/                 # [新增 M1]
│   │   ├── __init__.py
│   │   ├── models.py
│   │   └── rdkit_builder.py
│   └── postprocess/            # [新增 M2-M3]
│       ├── __init__.py
│       ├── models.py
│       ├── manager.py
│       ├── gaussian_tools.py
│       ├── multiwfn.py
│       ├── vmd.py
│       ├── profiles/
│       │   └── multiwfn-3.8.json
│       └── templates/
│           ├── orbital.tcl
│           ├── esp_surface.tcl
│           └── rdg.tcl
├── packaging/
│   └── gaussian-backend.spec   # [新增 M4]
├── scripts/
│   ├── build.mjs
│   ├── build_backend.ps1      # [新增 M4] 可逆绕过 pathlib backport
│   ├── deploy_runtime.ps1     # [新增 M4] 部署 runtimes + sha256 清单
│   └── smoke_test_backend.ps1 # [新增 M4]
├── runtimes/
│   └── win32-x64/
│       └── gaussian-backend/
│           └── gaussian-backend.exe
├── docs/
│   ├── PLAN.md                 # 本文件
│   ├── STATUS.md               # 项目状态记录
│   └── LESSONS_LEARNED.md      # 经验文档
├── src/
│   ├── index.js
│   └── client.js
├── lib/
│   ├── index.js
│   └── client.js
├── package.json
├── cordis.patch.yml
├── README.md
└── start_backend.bat
```
