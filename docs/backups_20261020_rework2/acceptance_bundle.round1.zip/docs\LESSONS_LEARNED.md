# 经验文档（Lessons Learned）

> 记录执行过程中的错误和修复经验，避免重复踩坑。

## 2026-10-20

### 1. Gaussian Link 0 命令顺序：%NoSave 必须在 %Chk 之前
- **错误**：先写 `%chk=xxx.chk` 再写 `%nosave`，Gaussian 会删除 chk 文件
- **原因**：%NoSave 会删除其之前命名的所有 scratch 文件（包括 chk）
- **正确写法**：`%mem=... %nprocshared=... %nosave %chk=xxx.chk`，或者直接不写 %nosave
- **影响**：后处理链（formchk → Multiwfn）拿不到 checkpoint，整个流程断裂
- **来源**：https://www.cenapad.unicamp.br/parque/manuais/Gaussian/00000483.htm

### 2. PyInstaller one-file 模式下 sys.executable 指向 exe 自己
- **错误**：子进程调用 `[sys.executable, script.py]`，冻结后变成 `gaussian-backend.exe script.py`
- **原因**：PyInstaller 冻结后 sys.executable 是打包后的 exe 路径，不再是 python.exe
- **解决方案**：新增 SOBKO_PYTHON_EXE 环境变量配置，冻结模式下必须显式指定 Python 路径
- **来源**：https://www.pyinstaller.org/en/stable/runtime-information.html

### 3. 15 GB 内存机器上的资源互斥
- **教训**：Gaussian 12 GB + Multiwfn 网格计算 + VMD 渲染，三者绝对不能同时跑
- **解决方案**：ChemComputeScheduler lease 机制，重型计算统一互斥
- **网格估算**：250³ 单 float64 数组 = 119 MiB，6 个数组 = 715 MiB；300³ 就到 2 GB
- **默认限制**：POSTPROCESS_MAX_GRID_POINTS = 16,000,000（≈252³）

### 4. Multiwfn 菜单数字会随版本漂移
- **教训**：不能把菜单数字硬编码在 Python 代码里
- **解决方案**：版本化 profile JSON + banner probe，未知版本 fail-fast
- **profile 文件**：backend/postprocess/profiles/multiwfn-3.8.json

### 5. RDKit MMFF 默认忽略片段间相互作用
- **教训**：盐（如 [NH4+].[Cl-]）用 MMFF 优化时，阴阳离子相对位置没有物理意义
- **原因**：MMFF API 默认 ignoreInterfragInteractions=true
- **解决方案**：多片段体系默认拒绝，要求 allow_disconnected=True 才处理
- **来源**：https://www.rdkit.org/docs/cppapi/MMFF_8h_source.html

### 6. PyInstaller 启动即退出：旧 pathlib backport 的 dist-info（M4）
- **现象**：base 环境装了 `pathlib 1.0.1` backport（只剩 dist-info 元数据，无包代码，import 仍走标准库），PyInstaller 6.x 在 compat.py 启动期 `distribution("pathlib")` 命中元数据就 raise SystemExit，命令行参数无法绕过。
- **错误做法**：在 base 里 pip uninstall（违反"不污染现有工作流环境"规则）。
- **正确做法（零下载、可逆）**：构建脚本 try 里把 `pathlib-1.0.1.dist-info` 临时改名为 `.__tmp_rename`，finally 无条件改回；不卸载、不删文件，环境最终与构建前一致。备份在 docs/backups_20261020/。
- **检查点**：改名后 `python -m PyInstaller --version` 能正常返回即说明绕过生效。

### 7. PyInstaller 拒绝同时收集 PyQt5 + PyQt6（M4）
- **现象**：base 环境两套 Qt 绑定并存，分析阶段报"multiple Qt bindings packages"中止。
- **解决**：后端根本不用 Qt，在 spec 的 excludes 里显式排除 PyQt5/PyQt6/PySide2/PySide6/qtpy。

### 8. conda 的 OpenSSL DLL 不会被 PyInstaller 自动收集（M4）
- **现象**：exe 启动报 `ImportError: DLL load failed while importing _ssl: 找不到指定的程序`（anyio→ssl→_ssl.pyd 缺 libcrypto/libssl）。
- **原因**：标准 hook 只收证书，conda 的 libssl-3-x64.dll/libcrypto-3-x64.dll 在 `Library\bin`，不在 pythonDLLs。
- **解决**：spec 里按 `sys.executable` 推导 `Library\bin`，glob `libssl-*.dll/libcrypto-*.dll` 加入 binaries（跳过 .conda_trash/.pdb）。

### 9. PowerShell 的 try 必须配 catch 或 finally，且 try 内不要用 exit（M4）
- **现象**：解析报"Try 语句缺少 Catch 或 Finally"，常因 try 块内 `exit 1` 让控制流与大括号错位。
- **解决**：try/catch/finally 完整结构，块内用 `throw` + `$buildOk` 标志，退出码在 finally 之后统一判断。

### 10. pydantic 模型不能用 dataclasses.asdict（M2 遗留，M6 回归时暴露）
- **现象**：postprocess manager 把 pydantic 的 PostprocessTask 传给 `dataclasses.asdict()`，create_task 保存时抛 `TypeError: asdict() should be called on dataclass instances`。
- **原因**：M2 写 manager 时误用了 dataclasses 工具，而任务模型是 pydantic BaseModel；此前端到端没真正创建过 postprocess 任务，所以一直没触发。
- **解决**：全部改用 `task.model_dump()`；pydantic 写入 JSON 用 model_dump，不要 import asdict。
- **提醒**：单测只覆盖命令生成、没走到持久化时，这类 bug 会潜伏，端点级 TestClient 回归才能抓到。

### 11. DSH managed 生命周期协议（M5）
- 前端 `ctx.inject(["subprocess"], child => child.effect(() => { owned.start(); return async () => owned.dispose(); }))`；
- 后端 stdout 打一行 ready record `{"event":"ready","service","version","baseUrl"}`，前端也可用轮询 /v1/health 兜底；
- dispose 只 terminate 自己 owned 的进程，reuse 的别人进程绝不动；Gaussian 子进程由 /v1/admin/shutdown 保留、下次启动 reconcile 接管。
- health 必须校验 `service` 名，不能只看 200，避免把同端口的其他服务误当后端。

### 12. DSH `handle.done` 是 Promise，不是布尔（B3，第二轮）
- **错误**：`if (handle.done)` 判断子进程是否退出——done 是 `Promise<SubprocessOutcome>`，对象恒为 truthy，进程还在跑也为真。
- **正确**：`handle.done.then(finish, finish)` 订阅 settle，与 health 轮询 `Promise.race`；退出信号只从回调来，不从对象本身判断。
- **契约**：以官方 subprocess.md 与参考插件 `@aifs/dsh-plugin-aifs` 的 `handle.done.then(...)` 用法为准，不凭 API 名字猜。

### 13. SpawnSpec.cwd 是必需字符串，不要传 undefined（B4，第二轮）
- **错误**：`cwd: this.config.dataDir || undefined`，默认 dataDir=null 时把 undefined 传进必需字段。
- **正确**：先解析一个真实存在的绝对目录（dataDir→exe 所在目录，缺失则 mkdir）；实在拿不到就**省略 cwd 键**让运行时用默认，而不是塞 undefined。

### 14. 提交边界校验必须放在"最后一道"，不能只保护输入生成接口（B7，第二轮）
- **现象**：`_check_atom_count` 只在 SMILES/坐标生成接口生效，`POST /v1/jobs` 直接收 gjf_content 原样落盘提交，原子数/%mem/%nproc 全被绕过。
- **做法**：在 job_manager.submit 内部对原始 GJF 文本再做一次 validate_gjf（原子数、%mem 换算 MB、%nproc、电荷/多重度）；任何入口最终都过这道关。
- **易错点**：多重度 = 2S+1，可取 2（双态），**不是必须奇数**；初版误写成"必须奇数"已纠正。

### 15. 长连接 stdio：阻塞 readline 无法超时，必须用读线程+缓冲（M7，第二轮）
- **错误**：`while` 里 `readline()` 卡在没有新行时，前面的 `time.time()-start` 超时检查根本执行不到；stderr=PIPE 不消费还会写满反堵。
- **做法**：后台 daemon 线程把 stdout 原始字节写进加锁缓冲，_recv_json 轮询缓冲按 Content-Length 取帧；stderr 单独线程消费留最近若干行；超时直接放弃并 kill 释放锁。
- **验证**：卡死子进程应在设定超时（如 1.5s）返回 None，而不是等到子进程自己结束。

### 16. 化学结果解析要"按方法取对应能量/按最后一步取轨道"（B8/M10/M9，第二轮）
- MP2/CCSD 不能拿 SCF Done 的参考态当相关能：MP2 取 EUMP2、CCSD 取 E(CCSD)，数值正则要兼容 Fortran 科学计数 `E+02`。
- 优化轨迹每步都打印轨道，HOMO/LUMO 取**最后一组** occ/virt（终态 SCF），不要遍历取全局最大。
- 开壳层 α/β 能级不同，MO 图必须两栏并列、各自算 gap；只有 α 会误导。
