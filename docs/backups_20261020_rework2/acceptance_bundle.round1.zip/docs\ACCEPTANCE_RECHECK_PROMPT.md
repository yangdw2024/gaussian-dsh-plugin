# 复验提示词（第二轮，修复后复核）— 复制给评审 AI

> 用法：把「==== 复验任务开始 ====」以下整段复制给评审 AI，并按文末清单附上文件（已打包在 `acceptance_bundle.zip`）。
> 定位：这是**返工后的逐条复核**，不是从零评审。重点核对首轮 9 Blocker / 12 Major / 3 Minor 是否真的闭环，以及修复有没有引入新问题。**只读、不改、不装软件、不要求评审机跑真实化学计算。**

==== 复验任务开始 ====

## 你是谁
你是资深静态评审工程师，精通 Python FastAPI（pydantic v2、子进程、PyInstaller 冻结）与 DSH/Cordis 插件生命周期（managed spawn/reuse/dispose、`subprocess` 契约、HTTP tool 注册），熟悉 Gaussian 16 / formchk / Multiwfn / VMD / RDKit / fchk。
**只评审、只读；不要改文件、不要装依赖、不要假设评审机有 Gaussian/RDKit/Multiwfn/VMD。** 不要轻信 `docs/FIX_REPORT_20261020.md` 的"已修复"声明——每条都要自己打开代码核实。

## 背景
项目 `gaussian-dsh-plugin` 是 DSH 客户端里的 Gaussian 辅助插件：Cordis 前端经 HTTP 调本地 FastAPI 后端，覆盖输入生成、输出解析、串行任务队列、BSE 基组、Sobko 检索、SMILES→3D、Multiwfn/VMD 后处理、PyInstaller onedir 打包。
第一轮静态评审给出"需返工"，本包是修复后的版本。你的任务是**逐条复核首轮问题是否闭环**，并检查修复是否带来回归。

## 一、Blocker 逐条复核（必须给出 已闭环 / 部分闭环 / 未闭环 + 文件:行号证据）

- **B1 统一计算 lease**：核对 `backend/job_manager.py` 的 `submit()` 是否先 `chem_scheduler.acquire(job_id,"gaussian")`（scheduler 内部加锁，消除并发同时通过 has_running），启动失败/异常是否 `_release_lease`，reconcile 接管存活 PID 是否重新 acquire；`backend/app.py` 两个 SMILES 端点是否对 `smiles_to_3d` 短持 `rdkit` lease（try/finally）、busy 转 409。Gaussian Popen 是否脱离控制台组（CREATE_NEW_PROCESS_GROUP）。
- **B5 标准 logger**：`backend/app.py` 是否已用 `logging.getLogger(...)` 替换全部 `app.logger`，覆盖 adopted job / GC 删除 / reconcile 异常三条启动路径，不再依赖 FastAPI 实例 logger。
- **B6 管理端点强制认证**：`_require_admin()` 是否在配 token 时校验 Bearer、未配 token 时仅放行回环 host；CORS 是否去掉 `*`+credentials。匿名非回环调 shutdown/gc 应被挡。
- **B7 提交边界 GJF 校验**：`backend/gaussian_input.py` 的 `validate_gjf()` 是否在 submit 内对**原始 gjf_content** 校验原子数、`%mem`（换算 MB 不超预算）、`%nprocshared`、电荷/多重度；注意多重度=2S+1，允许 2（双态），**不应写成"必须奇数"**。
- **B8 MP2/最终能量**：`backend/gaussian_output.py` 是否 MP2 取 EUMP2、CCSD 取 E(CCSD)，不把 SCF 参考态当相关能；数值正则是否兼容 Fortran 科学计数 `E[+-]dd`。
- **B9 stop_job 复核**：`backend/job_manager.py` stop_job 是否检查 taskkill 返回码、轮询确认 PID 消失，未确认不落 stopped；是否避免 PID 复用误杀。
- **B2 dispose 不误杀 Gaussian**：`src/index.js` dispose 是否先受控 `/v1/admin/shutdown`、等 waitForExit，仅超时才兜底 terminate；结合后端独立进程组，Gaussian 不在可清理句柄范围。
- **B3 done 是 Promise 不是布尔**：`_waitReady()` 是否 `handle.done.then(...)` 订阅退出并与 health 轮询 Promise.race，**禁止出现 `if(handle.done)` 当布尔**。
- **B4 cwd 必需字符串**：spawn 是否解析真实存在的绝对目录，拿不到时省略 cwd 键，**不得传 undefined**。

## 二、Major 逐条复核

- **M1 统一完成判据**：`_finalize_if_dead` 是否读 "Normal termination of Gaussian" 落 completed/failed，has_running/get_job/reconcile 复用同一判据，不再见 PID 退出就无条件 failed。
- **M2 后处理状态真实**：orbitals/esp/rdg 只生成命令的分支是否标 `prepared`（不谎称 completed）；mo_levels 校验 SVG 存在非零才 completed。
- **M3 前端后处理工具**：`src/index.js` 是否注册 capabilities / create_task / get_task / list_task 工具。
- **M4 Multiwfn 版本真探测**：`probe_version()` 是否真启动抓 banner 正则，失败返回 None，不再硬编码 "3.8"。
- **M5 网格预检**：是否有提交前保守上界 + 生成后 cube header 复核钩子；固定三档是否仍可能越过 1600 万。
- **M6 产物落位**：后处理产物是否统一到 `data_dir/postprocess/<task_id>` 纳入 GC，而不是散在 work_dir。
- **M7 Sobko 可超时**：`backend/sobko_client.py` 是否用后台读线程+缓冲，`_recv_json` 真超时返回，stderr 被持续消费（不再阻塞 readline）。
- **M8 VMD 产物校验**：`vmd.py` 是否强制校验 TGA 存在、非零、可解码，缺失即 raise，不返回假 PNG 路径。
- **M9 开壳层 MO 图**：`fchk_reader.generate_mo_level_svg` 开壳层是否 α/β 两栏并列、各自 gap，缺 beta 显式告警，不再只画 alpha。
- **M10 最后一组轨道**：HOMO/LUMO 是否取最后一组 occ/virt（终态 SCF），不遍历优化步取全局最大。
- **M11 disposed 竞态**：是否有 `disposed` 终态标志，卸载后不再把启动中的进程置 owned。
- **M12 stdio 消费**：spawn 是否避免无消费者的 pipe（改 ignore 或持续 drain），防止缓冲满反堵。

## 三、Minor 复核
- **m1** `package.json` version 是否与后端 0.2.0 一致。
- **m2** `src/client.js` 是否去掉硬编码 127.0.0.1:8765，改为可配置 baseUrl + 回环兜底。
- **m3** `scripts/build_backend.ps1`：one-file 未实现时是否直接拒绝；onedir exe 缺失是否失败退出而非 WARNING 后 exit 0。

## 四、回归与检查（修复后必查）
1. 改动文件是否引入新的未定义变量、import 缺失、缩进/语法问题；pydantic 是否仍用 model_dump（不要退回 asdict）。
2. B7 校验是否会误拒合法输入（多重度=2、常规 mem/nproc）。
3. lease 获取/释放是否成对，异常路径有没有泄漏 lease 导致后续全部 409。
4. 前端 dispose/start 时序是否仍存在竞态；CORS 收紧是否误伤本机正常调用。
5. 化学解析改动是否影响闭壳层 HF/DFT 的既有正确结果。

## 五、有意保留、禁止误判为 blocker
- 后端源码改完，PyInstaller onedir exe **尚未重打**（runtimes 仍是旧版），这是部署步骤，不是代码缺陷。
- 真实 chk→formchk→Multiwfn→VMD 端到端未跑、真实 DSH managed 联调未做；可评价接口预留是否正确，不能要求现场演示。
- one-file 明确未实现（开关会拒绝），不判缺陷。

## 输出格式（严格遵守）
1. **总体结论**：可交付 / 有条件交付 / 需返工，一句话。
2. **逐条核对表**：B1–B9、M1–M12、m1–m3 每行列 `状态(闭环/部分/未闭环) — 证据 文件:行号 — 一句话说明`。
3. **新发现问题**：`[级别] 文件:行号 — 问题 — 影响 — 建议`；没有就写"未发现新问题"，不要凑数。
4. **回归项检查结果**（第四部分 1–5 逐条给结论）。
5. **优点**：3–5 点，必须有代码证据。
6. 禁止编造评审机无法验证的运行结果，禁止给无依据的化学结论。

==== 复验任务结束 ====

---

## 提交给复验 AI 的文件清单

### 应该提交（已在 acceptance_bundle.zip 内，纯文本，约 110KB）
**配置/说明（根目录）**
- `README.md`、`package.json`、`cordis.patch.yml`、`start_backend.bat`

**文档（先建立全貌与修复声明）**
- `docs/FIX_REPORT_20261020.md`（本轮修复对照，评审要核对其声明是否属实）
- `docs/STATUS.md`、`docs/PLAN.md`、`docs/LESSONS_LEARNED.md`、`docs/ACCEPTANCE_PROMPT.md`、本复验提示词

**后端源码（全部）**
- `backend/app.py`、`config.py`、`entrypoint.py`、`resource_scheduler.py`、`process_utils.py`、`memory_guard.py`、`artifact_gc.py`
- `backend/gaussian_input.py`（B7 validate_gjf）、`gaussian_output.py`（B8/M10）、`job_manager.py`（B1/B9/M1）、`sobko_client.py`（M7）、`fchk_reader.py`（M9）
- `backend/basis_set.py`、`keywords.py`
- `backend/smiles/`（`__init__.py`、`models.py`、`rdkit_builder.py`）
- `backend/postprocess/`（`__init__.py`、`models.py`、`manager.py`、`gaussian_tools.py`、`multiwfn.py`、`vmd.py`、`profiles/multiwfn-3.8.json`、`templates/orbital.tcl`、`esp_surface.tcl`、`rdg.tcl`）

**前端源码（给 src，不给压缩产物）**
- `src/index.js`（B2/B3/B4/M3/M11/M12）、`src/client.js`（m2）

**打包/脚本**
- `packaging/gaussian-backend.spec`
- `scripts/build_backend.ps1`（m3）、`deploy_runtime.ps1`、`smoke_test_backend.ps1`、`build.mjs`

### 不要提交
- `runtimes/`（exe 与 `_internal`，142MB 二进制/DLL，且为旧版）
- `lib/`（esbuild 产物，评审看 `src/`）
- 所有 `__pycache__/`、`.pyc`
- `docs/backups_*`（本地旧版备份，会干扰对照）
- `.bundle_stage`（临时，已清理）
